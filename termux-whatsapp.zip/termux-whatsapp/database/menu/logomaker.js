const logomaker = (prefix, botName, ownerName) => {
        return `
「 *${botName}* 」

◪ *INFO*
  ❏ Prefix:o 「  ${prefix}  」
  ❏ Criador: ${sozin}
◪ *SOBRE*
  │
  ├─ ❏ ${prefix}info
  ├─ ❏ ${prefix}blocklist
  ├─ ❏ ${prefix}chatlist
  ├─ ❏ ${prefix}ping
  └─ ❏ ${prefix} numero do dono 351925955554
◪ *LOGOTIPO CRIADOR *
  │
  ├─ ❏ ${prefix}marvellogo
  ├─ ❏ ${prefix}ninjalogo
  ├─ ❏ ${prefix}logowolf
  ├─ ❏ ${prefix}logowolf2
  ├─ ❏ ${prefix}phlogo
  ├─ ❏ ${prefix}neonlogo
  ├─ ❏ ${prefix}neonlogo2
  ├─ ❏ ${prefix}lionlogo
  └─ ❏ ${prefix}jokerlogo
◪ *DE OUTROS*
  │
  ├─ ❏ ${prefix}send     ° ʙᴏᴛ ғᴀᴢᴇʀ sᴘᴀᴍ ᴅᴇ ᴄʜᴀᴍᴀᴅᴀs
  ├─ ❏ ${prefix}wame   ° ᴘᴇɢᴀʀ sᴇᴜ ɴúᴍᴇʀᴏ ᴇᴍ ғᴏʀᴍᴀ ᴅᴇ ʟɪɴᴋ
  ├─ ❏ ${prefix}virtex
  ├─ ❏ ${prefix}qrcode. ° ǫʀ ᴄᴏᴅᴇ ᴅᴏ ʙᴏᴛ
  ├─ ❏ ${prefix}timer
  ├─ ❏ ${prefix}fml
  └─ ❏ ${prefix}fml2
◪ *{DONO}*`
}
exports.logomaker = logomaker
